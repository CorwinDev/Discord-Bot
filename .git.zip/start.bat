node . --trace-warnings
PAUSE